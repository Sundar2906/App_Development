package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Plantify1Application {

	public static void main(String[] args) {
		SpringApplication.run(Plantify1Application.class, args);
	}

}
