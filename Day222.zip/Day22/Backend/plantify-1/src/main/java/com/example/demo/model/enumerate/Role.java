package com.example.demo.model.enumerate;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public enum Role 
{
    ADMIN,
    CUSTOMER
}
